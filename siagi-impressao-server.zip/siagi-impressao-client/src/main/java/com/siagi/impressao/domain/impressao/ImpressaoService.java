package com.siagi.impressao.domain.impressao;

import java.awt.print.PrinterJob;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Base64;
import javax.print.PrintService;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.HashPrintServiceAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.PrintServiceAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.PrinterName;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPrintServiceExporter;
import net.sf.jasperreports.engine.export.JRPrintServiceExporterParameter;
import org.springframework.stereotype.Service;

@Service
public class ImpressaoService
{

    public void imprimir(ImpressaoValidPost impressaoValidPost)
    {
        JasperPrint etqObj = null;
        try {

            try {
                etqObj = (JasperPrint) deserializeObject(impressaoValidPost.getBase64());
            }
            catch (Exception e) {
                e.printStackTrace();
            }

            PrintService service = null;
            PrintService[] services = PrinterJob.lookupPrintServices();
            for (PrintService serv : services) {
                if (serv.getName().toLowerCase().contains("EPSON L5190 Series".toLowerCase())) {
                    service = serv;
                    break;
                }
            }

            PrintRequestAttributeSet printRequestAttributeSet = new HashPrintRequestAttributeSet();
            printRequestAttributeSet.add(new Copies(1));

            PrintServiceAttributeSet printServiceAttributeSet = new HashPrintServiceAttributeSet();
            printServiceAttributeSet.add(new PrinterName(service.getName(), null));
            JRPrintServiceExporter exporter = new JRPrintServiceExporter();
            exporter.setParameter(JRExporterParameter.JASPER_PRINT, etqObj);
            exporter.setParameter(JRPrintServiceExporterParameter.PRINT_REQUEST_ATTRIBUTE_SET, printRequestAttributeSet);
            exporter.setParameter(JRPrintServiceExporterParameter.PRINT_SERVICE_ATTRIBUTE_SET, printServiceAttributeSet);
            exporter.setParameter(JRPrintServiceExporterParameter.DISPLAY_PAGE_DIALOG, Boolean.FALSE);
            exporter.setParameter(JRPrintServiceExporterParameter.DISPLAY_PRINT_DIALOG, Boolean.FALSE);
            exporter.exportReport();

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static Object deserializeObject(String base64EncodedObject) throws IOException, ClassNotFoundException
    {
        byte[] decodedBytes = Base64.getDecoder().decode(base64EncodedObject);
        ByteArrayInputStream bis = null;
        ObjectInputStream ois = null;
        try {
            bis = new ByteArrayInputStream(decodedBytes);
            ois = new ObjectInputStream(bis);
            return ois.readObject();
        }
        finally {
            if (ois != null) {
                ois.close();
            }
            if (bis != null) {
                bis.close();
            }
        }
    }
}
