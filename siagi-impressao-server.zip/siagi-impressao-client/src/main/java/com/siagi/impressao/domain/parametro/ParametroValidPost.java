package com.siagi.impressao.domain.parametro;

import com.siagi.impressao.domain.parametro.Parametro.Escopo;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParametroValidPost
{

    @NotNull
    private Escopo escopo;

    @NotBlank
    private String chave;

    @NotBlank
    private String valor;

}
