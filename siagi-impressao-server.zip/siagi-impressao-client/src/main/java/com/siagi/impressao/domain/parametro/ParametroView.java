package com.siagi.impressao.domain.parametro;

import com.siagi.impressao.domain.parametro.Parametro.Escopo;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
public class ParametroView
{

    private Long id;
    private Escopo escopo;
    private String chave;
    private String valor;

    public ParametroView(Parametro entity)
    {
        this.id = entity.getId();
        this.escopo = entity.getEscopo();
        this.chave = entity.getChave();
        this.valor = entity.getValor();
    }

    public static List<ParametroView> toList(List<Parametro> list)
    {
        return list.stream().map(ParametroView::new).collect(Collectors.toList());
    }

}
