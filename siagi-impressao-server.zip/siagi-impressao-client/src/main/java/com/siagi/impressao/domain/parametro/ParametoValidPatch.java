package com.siagi.impressao.domain.parametro;

import com.siagi.impressao.domain.parametro.Parametro.Escopo;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParametoValidPatch {

  @NotNull
  private Long id;

  private Escopo escopo;

  private String chave;

  private String valor;

}
