package com.siagi.impressao.domain.parametro;

import java.io.Serializable;
import java.util.Objects;

public class TesteData implements Serializable
{
    
    private static final long serialVersionUID = -1L;
    
    private String teste;

    public TesteData(String teste)
    {
        this.teste = teste;
    }

    public String getTeste()
    {
        return teste;
    }

    public void setTeste(String teste)
    {
        this.teste = teste;
    }

    @Override
    public int hashCode()
    {
        int hash = 5;
        hash = 47 * hash + Objects.hashCode(this.teste);
        return hash;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TesteData other = (TesteData) obj;
        return Objects.equals(this.teste, other.teste);
    }
    
    
}
