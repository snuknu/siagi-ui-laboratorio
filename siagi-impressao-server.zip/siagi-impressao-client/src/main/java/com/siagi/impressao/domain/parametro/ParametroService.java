package com.siagi.impressao.domain.parametro;

import com.siagi.impressao.config.MessageUtil;
import java.util.Optional;
import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class ParametroService
{

    @Autowired
    private ParametroRepository parametroRepository;

    @Autowired
    private MessageUtil msg;

    public Page<Parametro> list(Pageable pageable)
    {
        return parametroRepository.findAllByAtivoTrue(pageable);
    }

    public Page<Parametro> list(Parametro.Escopo groupo, Pageable pageable)
    {
        return parametroRepository.findAllByEscopo(groupo, pageable);
    }

    public Parametro get(Long id)
    {
        return parametroRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(msg.get("lab.parametrizacao.nao.encontrado")));
    }

    public Parametro create(ParametroValidPost dto)
    {
        return parametroRepository.save(new Parametro(dto));
    }

    public Parametro put(ParametroValidPut dto)
    {
        Parametro entity = parametroRepository.getReferenceById(dto.getId());
        entity.setEscopo(dto.getEscopo());
        entity.setChave(dto.getChave());
        entity.setValor(dto.getValor());
        return parametroRepository.save(entity);
    }

    public Parametro patch(ParametoValidPatch dto)
    {
        Parametro entity = parametroRepository.getReferenceById(dto.getId());
        Optional.ofNullable(dto.getEscopo()).ifPresent(value -> entity.setEscopo(value));
        Optional.ofNullable(dto.getChave()).ifPresent(value -> entity.setChave(value));
        Optional.ofNullable(dto.getValor()).ifPresent(value -> entity.setValor(value));
        return parametroRepository.save(entity);
    }

    public Parametro disable(Long id)
    {
        Parametro entity = parametroRepository.getReferenceById(id);
        entity.setAtivo(Boolean.FALSE);
        return parametroRepository.save(entity);
    }

    public void delete(Long id)
    {
        parametroRepository.deleteById(id);
    }
}
