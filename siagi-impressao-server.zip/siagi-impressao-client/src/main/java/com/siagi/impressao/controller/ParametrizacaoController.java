package com.siagi.impressao.controller;

import com.siagi.impressao.domain.parametro.ParametoValidPatch;
import com.siagi.impressao.domain.parametro.Parametro;
import com.siagi.impressao.domain.parametro.ParametroService;
import com.siagi.impressao.domain.parametro.ParametroValidPost;
import com.siagi.impressao.domain.parametro.ParametroValidPut;
import com.siagi.impressao.domain.parametro.ParametroView;
import io.swagger.v3.oas.annotations.Parameter;
import java.net.URI;
import javax.validation.Valid;
import org.springdoc.core.converters.models.PageableAsQueryParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

@RestController
@RequestMapping("/parametrizacao")
public class ParametrizacaoController extends LabBaseController
{

    @Autowired
    private ParametroService service;

    @Secured(IMP_CADASTRAR_PARAMETROS_SISTEMA)
    @PostMapping
    public ResponseEntity<ParametroView> create(@RequestBody @Valid ParametroValidPost dto, UriComponentsBuilder uriBuilder)
    {
        ParametroView ietodoAnalise = new ParametroView(service.create(dto));
        URI uri = uriBuilder.path("parametro/{id}").buildAndExpand(ietodoAnalise.getId()).toUri();
        return ResponseEntity.created(uri).body(ietodoAnalise);
    }

    @Secured(IMP_CADASTRAR_PARAMETROS_SISTEMA)
    @GetMapping
    @PageableAsQueryParam
    public ResponseEntity<Page<ParametroView>> list(@Parameter(hidden = true) @PageableDefault(size = 10, page = 0, sort = "id") Pageable pageable)
    {
        return ResponseEntity.ok(service.list(pageable).map(ParametroView::new));
    }

    @Secured(IMP_CADASTRAR_PARAMETROS_SISTEMA)
    @GetMapping(path = "/escopo/{escopo}")
    @PageableAsQueryParam
    public ResponseEntity<Page<ParametroView>> list(@PathVariable Parametro.Escopo escopo, @Parameter(hidden = true) @PageableDefault(size = 10, page = 0, sort = "id") Pageable pageable)
    {
        return ResponseEntity.ok(service.list(escopo, pageable).map(ParametroView::new));
    }

    @Secured(IMP_CADASTRAR_PARAMETROS_SISTEMA)
    @GetMapping(path = "/{id}")
    public ResponseEntity<ParametroView> get(@PathVariable Long id)
    {
        return ResponseEntity.ok(new ParametroView(service.get(id)));
    }

    @Secured(IMP_CADASTRAR_PARAMETROS_SISTEMA)
    @PutMapping
    public ResponseEntity<ParametroView> put(@RequestBody @Valid ParametroValidPut dto)
    {
        return ResponseEntity.ok(new ParametroView(service.put(dto)));
    }

    @Secured(IMP_CADASTRAR_PARAMETROS_SISTEMA)
    @PatchMapping
    public ResponseEntity<ParametroView> patch(@RequestBody @Valid ParametoValidPatch dto)
    {
        return ResponseEntity.ok(new ParametroView(service.patch(dto)));
    }

    @Secured(IMP_ADMINISTRADOR)
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id)
    {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @Secured(IMP_CADASTRAR_PARAMETROS_SISTEMA)
    @DeleteMapping("/{id}")
    public ResponseEntity<ParametroView> disable(@PathVariable Long id)
    {
        return ResponseEntity.ok(new ParametroView(service.disable(id)));
    }

}
