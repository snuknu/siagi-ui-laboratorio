package com.siagi.impressao.util;

public class RegexpValidation
{

    public static final String EMAIL = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
}
