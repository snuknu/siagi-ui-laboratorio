package com.siagi.impressao.config;

import com.siagi.auth.bean.PermissaoFiltro;
import com.siagi.auth.token.ProcessamentoToken;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class TokenFilter extends OncePerRequestFilter
{

    private static final Integer SISTEMA = 148;
    private static final Integer EMPRESA = 0;
    private static final Integer LOCAL = 0;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws
            ServletException,
            IOException
    {
        String token = request.getHeader("AUTH-Token");

        if (StringUtils.isNotBlank(token)) {
            String empresa = request.getHeader("empresa");
            String local = request.getHeader("local");
            
            PermissaoFiltro contexto = new PermissaoFiltro(SISTEMA,
                    (StringUtils.isBlank(empresa) ? EMPRESA : Integer.valueOf(empresa)),
                    (StringUtils.isBlank(local) ? LOCAL : Integer.valueOf(local)));

            List<PermissaoFiltro> lista = Arrays.asList(contexto);
            UsernamePasswordAuthenticationToken auth = ProcessamentoToken.obterFilter().verificarUsuario(token, lista);
            SecurityContextHolder.getContext().setAuthentication(auth);
        }

        filterChain.doFilter(request, response);
    }

}
