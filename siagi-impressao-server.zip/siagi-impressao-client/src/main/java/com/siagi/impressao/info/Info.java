package com.siagi.impressao.info;

public class Info
{

    public static final String VERSION = "0.0.1";
    public static final String DESCRIPTION = "API do Sistema de Impress�o.";

    private static Info instance;
    private final String version;
    private final String description;

    private Info(String version, String description)
    {
        this.version = version;
        this.description = description;
    }

    public static Info getInstance()
    {
        if (instance == null)
        {
            instance = new Info(VERSION, DESCRIPTION);
        }
        return instance;
    }

    public String getVersion()
    {
        return version;
    }

    public String getDescription()
    {
        return description;
    }

}
