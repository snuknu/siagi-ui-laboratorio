package com.siagi.impressao.domain.parametro;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Entity
@Table(name = "lab_parametro", catalog = "dbSIAGI", schema = "dbo")
@SuppressWarnings({"PersistenceUnitPresent", "ValidPrimaryTableName"})
public class Parametro implements Serializable
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Enumerated(value = EnumType.ORDINAL)
    private Escopo escopo;

    @NotBlank
    @Column(unique = true, nullable = false)
    private String chave;

    @NotBlank
    @Column(nullable = false)
    private String valor;

    @NotNull
    private Boolean ativo;

    public Parametro(ParametroValidPost dto)
    {
        this.escopo = dto.getEscopo();
        this.chave = dto.getChave();
        this.valor = dto.getValor();
        this.ativo = Boolean.TRUE;
    }

    public enum Escopo
    {

        CONFIGURACAO_SISTEMA("Configura��o do sistema."),
        CONDICAO_LABORATORIO("Condi��o do laborat�rio.");

        private final String info;

        private Escopo(String info)
        {
            this.info = info;
        }

        public String info()
        {
            return info;
        }

        public static Escopo get(int ordinal)
        {
            return values()[ordinal];
        }
    }

}
