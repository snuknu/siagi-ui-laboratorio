package com.siagi.impressao.controller;

import com.siagi.impressao.domain.impressao.ImpressaoService;
import com.siagi.impressao.domain.impressao.ImpressaoValidPost;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/imprimir")
public class ImpressaoController extends LabBaseController
{

    @Autowired
    private ImpressaoService service;

    @Secured(IMP_CADASTRAR_PARAMETROS_SISTEMA)
    @PostMapping
    public ResponseEntity<?> imprimir(@RequestBody @Valid ImpressaoValidPost impressaoValidPost)
    {
        service.imprimir(impressaoValidPost);
        return ResponseEntity.noContent().build();
    }

}
