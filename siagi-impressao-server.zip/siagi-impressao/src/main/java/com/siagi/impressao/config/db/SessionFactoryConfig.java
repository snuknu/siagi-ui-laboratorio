package com.siagi.impressao.config.db;

import java.io.IOException;
import java.util.Properties;
import javax.sql.DataSource;
import org.hibernate.SessionFactory;
import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

@Configuration
public class SessionFactoryConfig
{

    @Autowired
    @Qualifier("mssql")
    private DataSource mssqlDataSource;

    @Autowired
    private PhysicalNamingStrategy physicalNamingStrategy;

    @Bean(name = "entityManagerFactory")
    @Primary
    public SessionFactory getSessionFactory()
    {
        LocalSessionFactoryBean factory = new LocalSessionFactoryBean();
        factory.setDataSource(mssqlDataSource);
        if (factory.getHibernateProperties() == null) {
            factory.setHibernateProperties(new Properties());
        }
        factory.setPackagesToScan(new String[]{
            "com.siagi.impressao.domain"
        });
        

        factory.getHibernateProperties().put("hibernate.dialect", "org.hibernate.dialect.SQLServerDialect");
        factory.getHibernateProperties().put("hibernate.hbm2ddl.auto", "update");
        factory.getHibernateProperties().put("hibernate.show_sql", "true");
        factory.setPhysicalNamingStrategy(physicalNamingStrategy);

        try {
            factory.afterPropertiesSet();
        }
        catch (IOException ex) {
            ex.printStackTrace(System.err);
        }
        return factory.getObject();
    }

}
