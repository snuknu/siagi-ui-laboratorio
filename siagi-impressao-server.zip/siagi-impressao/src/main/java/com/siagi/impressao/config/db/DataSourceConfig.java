package com.siagi.impressao.config.db;

import banco.af.DTOAutenticacao;
import banco.utilitarios.CriptografadorDES;
import com.siagi.impressao.config.Ambiente;
import com.siagi.impressao.config.AmbienteBean;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
public class DataSourceConfig
{

    private static final int INITIAL_SIZE = 0;
    private static final int MAX_IDLE = 5;

    private static final String CHAVE = "Rxsggv#Xsajh376647123f@%";

    @Autowired
    @Qualifier("ambiente")
    private AmbienteBean ambiente;

    @Bean(name = "mssql")
    public DataSource getMssqlDataSource()
    {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

        String ipServer = obterIPServidor();
        int portaServer = obterPortaServidor();

        String endereco = "jdbc:sqlserver://" + ipServer + ":" + portaServer;
        endereco += ";encrypt=true;trustServerCertificate=true;";

        String database = "dbSIAGI";

        if (!ipServer.startsWith("100.64.249.")) {
            ambiente.setAmbiente(Ambiente.TESTE);
        }

        endereco += ";database = " + database;

        dataSource.setUrl(endereco);

        DTOAutenticacao auth = buscarCredenciaisParaAutenticacao();

//        dataSource.setUsername(auth.getLogin());
//        dataSource.setPassword(auth.getSenha());
        dataSource.setUsername("eric.carvalho");
        dataSource.setPassword("Warp6460");
        dataSource.setInitialSize(INITIAL_SIZE);
        dataSource.setMaxIdle(MAX_IDLE);
        return dataSource;
    }

    public static String obterIPServidor()
    {
        String ipServidor;

        try {
            String siagiHome = System.getenv("SIAGI_HOME");
            if (siagiHome == null) {
                String osName = System.getProperty("os.name");
                siagiHome = osName.toUpperCase().contains("WINDOWS") ? "C:/SIAGI" : "/var/siagi/";
            }
            /* Verificar se existe algum direcionamento diferenciado para tratamento dos bancos de dados do sistema */
            try (FileInputStream fis = new FileInputStream(siagiHome + "/conf/banco.properties")) {
                Properties config = new Properties();
                config.load(fis);
                ipServidor = config.getProperty("endereco.bd");
            }
        }
        catch (IOException e) {
            ipServidor = "10.1.10.85";
        }

        return ipServidor;
    }

    public static int obterPortaServidor()
    {
        int portaServidor;
        try {
            String siagiHome = System.getenv("SIAGI_HOME");
            if (siagiHome == null) {
                String osName = System.getProperty("os.name");
                siagiHome = osName.toUpperCase().contains("WINDOWS") ? "C:/SIAGI" : "/var/siagi/";
            }
            /* Verificar se existe algum direcionamento diferenciado para tratamento dos bancos de dados do sistema */
            try (FileInputStream fis = new FileInputStream(siagiHome + "/conf/banco.properties")) {
                Properties config = new Properties();
                config.load(fis);
                portaServidor = Integer.parseInt(config.getProperty("porta.bd").trim());
            }
        }
        catch (NullPointerException | NumberFormatException | IOException e) {
            portaServidor = 0;
        }
        if (portaServidor == 0) {
            portaServidor = 1433;
        }

        return portaServidor;
    }

    public static DTOAutenticacao buscarCredenciaisParaAutenticacao()
    {
        String siagiHome;
        if (System.getenv("SIAGI_HOME") == null) {
            String osName = System.getProperty("os.name");
            if (osName.toUpperCase().contains("WINDOWS")) {
                siagiHome = "C:/SIAGI";
            }
            else {
                siagiHome = "/var/siagi";
            }
        }
        else {
            siagiHome = System.getenv("SIAGI_HOME");
        }
        try (FileInputStream fis = new FileInputStream(siagiHome + "/auth/siagi-bd.properties")) {
            Properties config = new Properties();
            config.load(fis);
            if (config.getProperty("siagi.bd.username") != null) {
                String login = new String(CriptografadorDES.decriptografar(config.getProperty("siagi.bd.username").getBytes(), CHAVE));
                String senha = new String(CriptografadorDES.decriptografar(config.getProperty("siagi.bd.password").getBytes(), CHAVE));
                return new DTOAutenticacao(login, senha);
            }
        }
        catch (IOException ex) {
        }

        return null;
    }

}
