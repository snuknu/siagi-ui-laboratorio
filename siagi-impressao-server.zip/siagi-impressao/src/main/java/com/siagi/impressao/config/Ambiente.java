package com.siagi.impressao.config;

public enum Ambiente
{
    PRODUCAO("Produ��o", ""),
    TESTE("Teste", "_teste");

    private final String info;
    private final String sufixo;

    private Ambiente(String info, String sufixo)
    {
        this.info = info;
        this.sufixo = sufixo;
    }

    public String info()
    {
        return info;
    }

    public String sufixo()
    {
        return sufixo;
    }

    @Override
    public String toString()
    {
        return info;
    }

    public static Ambiente get(int i)
    {
        return values()[i];
    }

}
