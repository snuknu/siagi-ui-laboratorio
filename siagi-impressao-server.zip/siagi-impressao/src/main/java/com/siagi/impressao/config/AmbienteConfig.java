package com.siagi.impressao.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AmbienteConfig
{

    private static AmbienteBean ambiente;

    @Bean(name = "ambiente")
    public static AmbienteBean ambienteConfig()
    {
        ambiente = new AmbienteBean(Ambiente.PRODUCAO);
        return ambiente;
    }

    public static AmbienteBean getAmbienteBeanInstance()
    {
        return ambiente;
    }

}
