package com.siagi.impressao.domain.impressao;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Base64;
import java.util.HashMap;
import javax.transaction.Transactional;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class ImpressaoService
{

    public ImpressaoView imprimir(ConteudoValidPost conteudo)
    {

        ImpressaoView impressaoValidPost = new ImpressaoView();
        try {

            HashMap map = new HashMap();
            map.put("logotipo", conteudo.getConteudo());

            java.util.ArrayList<TesteData> lista = new java.util.ArrayList();
            lista.add(new TesteData(conteudo.getConteudo()));
            JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(lista);

            InputStream employeeReportStream = new FileInputStream(new File("C:/Users/eric.carvalho/teste.jasper"));
            JasperReport jasperReport = (JasperReport) JRLoader.loadObject(employeeReportStream);

            //JasperReport jasperReport  = (JasperReport) JRLoader.loadObject(employeeReportStream);
            JasperPrint etq = null;

            try {
                etq = JasperFillManager.fillReport(jasperReport, map, ds);

                String base64 = objectToString(etq);
                impressaoValidPost.setBase64(base64);

            }
            catch (JRException e) {
                e.printStackTrace();
            }

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return impressaoValidPost;
    }

    public static String objectToString(Serializable obj) throws IOException
    {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream(); ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeObject(obj);
            return Base64.getEncoder().encodeToString(baos.toByteArray());
        }
    }

}
