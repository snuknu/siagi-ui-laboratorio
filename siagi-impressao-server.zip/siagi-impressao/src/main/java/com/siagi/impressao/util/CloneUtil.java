package com.siagi.impressao.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class CloneUtil
{

    public static <T> T cloneUsingSerialization(T original)
    {

        T clone = null;
        try {
            ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(byteOut);
            out.writeObject(original);
            ByteArrayInputStream byteIn = new ByteArrayInputStream(byteOut.toByteArray());
            ObjectInputStream in = new ObjectInputStream(byteIn);
            clone = (T) in.readObject();
            in.close();
        }
        catch (IOException | ClassNotFoundException ex) {
            return null;
        }
        return clone;
    }
}
