package com.siagi.impressao.config.db;

import com.siagi.impressao.config.Ambiente;
import com.siagi.impressao.config.AmbienteBean;
import java.util.Locale;
import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;

@Configuration
public class NamingStrategyConfig implements PhysicalNamingStrategy
{

    @Autowired
    @Qualifier("ambiente")
    private AmbienteBean ambiente;

    @Override
    public Identifier toPhysicalCatalogName(Identifier logicalName, JdbcEnvironment jdbcEnvironment)
    {
        return withSuffix(logicalName, jdbcEnvironment);
    }

    @Override
    public Identifier toPhysicalSchemaName(Identifier logicalName, JdbcEnvironment jdbcEnvironment)
    {
        return apply(logicalName, jdbcEnvironment);
    }

    @Override
    public Identifier toPhysicalTableName(Identifier logicalName, JdbcEnvironment jdbcEnvironment)
    {
        return withSuffix(logicalName, jdbcEnvironment);
    }

    @Override
    public Identifier toPhysicalSequenceName(Identifier logicalName, JdbcEnvironment jdbcEnvironment)
    {
        return apply(logicalName, jdbcEnvironment);
    }

    @Override
    public Identifier toPhysicalColumnName(Identifier logicalName, JdbcEnvironment jdbcEnvironment)
    {
        return apply(logicalName, jdbcEnvironment);
    }

    public Identifier withSuffix(Identifier logicalName, JdbcEnvironment jdbcEnvironment)
    {
        if (logicalName != null) {

            String suffix = Ambiente.TESTE.equals(ambiente.getAmbiente())
                    ? Ambiente.TESTE.sufixo()
                    : Ambiente.PRODUCAO.sufixo();

            logicalName = apply(new Identifier(logicalName.getText().concat(suffix), logicalName.isQuoted()), jdbcEnvironment);
        }
        return logicalName;
    }

    private Identifier apply(final Identifier name, final JdbcEnvironment jdbcEnvironment)
    {
        if (name == null) {
            return null;
        }
        StringBuilder builder = new StringBuilder(name.getText().replace('.', '_'));
        for (int i = 1; i < builder.length() - 1; i++) {
            if (isUnderscoreRequired(builder.charAt(i - 1), builder.charAt(i), builder.charAt(i + 1))) {
                builder.insert(i++, '_');
            }
        }
        return getIdentifier(builder.toString(), name.isQuoted(), jdbcEnvironment);
    }

    
    protected Identifier getIdentifier(String name, final boolean quoted, final JdbcEnvironment jdbcEnvironment)
    {
        if (isCaseInsensitive(jdbcEnvironment)) {
            name = name.toLowerCase(Locale.ROOT);
        }
        return new Identifier(name, quoted);
    }

    protected boolean isCaseInsensitive(JdbcEnvironment jdbcEnvironment)
    {
        return true;
    }

    private boolean isUnderscoreRequired(final char before, final char current, final char after)
    {
        return Character.isLowerCase(before) && Character.isUpperCase(current)
                && Character.isLowerCase(after);
    }

}
