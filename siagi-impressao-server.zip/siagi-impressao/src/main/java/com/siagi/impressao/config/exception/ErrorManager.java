package com.siagi.impressao.config.exception;

import com.fasterxml.jackson.core.JsonParseException;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.persistence.EntityNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;

@RestControllerAdvice
public class ErrorManager
{

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorRead> handleException(Exception ex)
    {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorRead(coalesce(ex.getLocalizedMessage(), ex.getMessage())));
    }

    @ExceptionHandler(HttpClientErrorException.class)
    public ResponseEntity<ErrorRead> handleException(HttpClientErrorException ex)
    {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(new ErrorRead(coalesce(ex.getLocalizedMessage(), ex.getMessage())));
    }

    @ExceptionHandler(JsonParseException.class)
    public ResponseEntity<ErrorRead> handleJsonParseException(JsonParseException ex)
    {
        return ResponseEntity.badRequest()
                .body(new ErrorRead(coalesce(ex.getLocalizedMessage(), ex.getMessage())));
    }

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<ErrorRead> handleEntityNotFoundException(EntityNotFoundException ex)
    {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new ErrorRead(coalesce(ex.getLocalizedMessage(), ex.getMessage())));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorRead> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex)
    {
        return ResponseEntity.badRequest()
                .body(new ErrorRead(ex.getFieldErrors().stream().map(ArgumentNotValidError::new).collect(Collectors.toList())));
    }

    private static <T> T coalesce(T... items)
    {
        return Stream.of(items).filter(Objects::nonNull).findFirst().orElse(null);
    }

}
