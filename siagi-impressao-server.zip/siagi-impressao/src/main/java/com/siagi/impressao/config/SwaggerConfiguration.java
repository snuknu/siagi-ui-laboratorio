package com.siagi.impressao.config;

import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.media.StringSchema;
import io.swagger.v3.oas.models.parameters.Parameter;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.HandlerMethod;

@Configuration
public class SwaggerConfiguration
{

    @Bean
    public OperationCustomizer customGlobalHeaders()
    {

        return (Operation operation, HandlerMethod handlerMethod) -> {

            Parameter token = new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .schema(new StringSchema())
                    .name("AUTH-Token")
                    .description("Token")
                    .required(false);

            Parameter empresa = new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .schema(new StringSchema())
                    .name("empresa")
                    .description("Empresa")
                    .required(false);

            Parameter local = new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .schema(new StringSchema())
                    .name("local")
                    .description("Local")
                    .required(false);

            operation.addParametersItem(token);
            operation.addParametersItem(empresa);
            operation.addParametersItem(local);

            return operation;
        };
    }
}
