package com.siagi.impressao.controller;

public class LabBaseController
{

    protected static final int SISTEMA_DE_IMPRESSAO_SERVER = 148;

    protected static final int ADMINISTRADOR = 40;
    protected static final int CADASTRAR_PARAMETROS_SISTEMA = 1;

    protected static final String IMP_ADMINISTRADOR = SISTEMA_DE_IMPRESSAO_SERVER + "-" + ADMINISTRADOR;
    protected static final String IMP_CADASTRAR_PARAMETROS_SISTEMA = SISTEMA_DE_IMPRESSAO_SERVER + "-" + CADASTRAR_PARAMETROS_SISTEMA;

}
