package com.siagi.impressao.util;

public class RegexpValidation
{

    public static final String METODO_ANALISE = "^M(A|E)-10-652-[0-9]{10}-[a-zA-Z]{2}-[0-9]{3}$";
}
