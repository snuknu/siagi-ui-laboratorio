package com.siagi.impressao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(value = {"com.siagi.impressao"})
public class SiagiImpressaoApplication
{

    public static void main(String[] args)
    {
        SpringApplication.run(SiagiImpressaoApplication.class, args);
    }

}
