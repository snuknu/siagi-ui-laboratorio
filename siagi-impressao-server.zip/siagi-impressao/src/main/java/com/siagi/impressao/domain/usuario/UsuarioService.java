package com.siagi.impressao.domain.usuario;

import com.siagi.auth.bean.UsuarioView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService
{

    @Autowired
    public UsuarioService()
    {
    }

    public UsuarioView getUsuario()
    {
        UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            return (UsuarioView) auth.getDetails();
        }
        return null;
    }

    public Long getUsuarioCodigo()
    {
        return getUsuario().getCodigo();
    }

}
