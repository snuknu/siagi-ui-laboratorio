package com.siagi.impressao.config;

import java.util.Locale;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

@Component
public class MessageUtil
{

    @Autowired
    private MessageSource msg;

    public String get(String key, Locale... locales)
    {
        return msg.getMessage(key, null, (locales.length > 0 ? locales[0] : Locale.getDefault()));
    }

}
