package com.siagi.impressao.controller;

import com.siagi.impressao.domain.impressao.ConteudoValidPost;
import com.siagi.impressao.domain.impressao.ImpressaoService;
import com.siagi.impressao.domain.impressao.ImpressaoView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/imprimir")
public class ImpressaoController extends LabBaseController
{

    @Autowired
    private ImpressaoService service;

    @Secured(IMP_CADASTRAR_PARAMETROS_SISTEMA)
    @PostMapping
    public ResponseEntity<ImpressaoView> imprimir(@RequestBody ConteudoValidPost conteudo)
    {
        return ResponseEntity.ok(service.imprimir(conteudo));
    }

}
