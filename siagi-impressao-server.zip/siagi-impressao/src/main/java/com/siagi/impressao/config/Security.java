package com.siagi.impressao.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true, jsr250Enabled = true)
public class Security
{

    private static final String[] AUTH_SWAGGER =
    {
        "/v3/api-docs/**",
        "/swagger-ui/**"
    };

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception
    {
        return http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeRequests(authorizeRequests -> authorizeRequests
                .antMatchers(HttpMethod.GET, AUTH_SWAGGER).permitAll()
                .antMatchers(HttpMethod.GET, "/info").permitAll()
                .anyRequest().authenticated())
                .addFilterBefore(new TokenFilter(), BasicAuthenticationFilter.class)
                .build();
    }

    @Bean
    public AuthenticationManager noopAuthenticationManager()
    {
        return authentication ->
        {
            throw new AuthenticationServiceException("Authentication is disabled");
        };
    }

}
